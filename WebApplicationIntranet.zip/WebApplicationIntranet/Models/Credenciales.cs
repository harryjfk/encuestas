﻿namespace WebApplication.Models
{
   public  class Credenciales
    {
       public string Login { get; set; }
       public string Password { get; set; }
    }
}
